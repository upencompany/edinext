EDINEXT — LOGO PACK 2026
=========================

Contents
  svg/            vector logos (preferred for print and digital)
  png/            transparent PNG exports, width in pixels in the file name
  products/       product marks of Edinext applications

Variants
  edinext-logo-*       logo with the "Innovare × Crescere" tagline
  edinext-wordmark-*   logotype only (use when the tagline would be smaller than 3 mm / 12 px)
  edinext-symbol-*     the X alone (avatars, favicons, small spaces)

Colourways
  color     on white or very light backgrounds
  reverse   on dark backgrounds (Night #07101D, photographs)
  black     one-colour printing, fax, engraving
  white     one-colour on Edinext Blue #0076B9 or other dark colours

Rules (full details in the Brand Guidelines PDF)
  - Keep clear space around the logo equal to half the height of the letter "e".
  - Minimum width: wordmark 100 px / 25 mm, logo with tagline 160 px / 40 mm, symbol 16 px / 5 mm.
  - Do not recolour, stretch, rotate, outline or add effects. Do not rebuild the lettering with a font.

Brand colours
  Edinext Blue     #0076B9   RGB 0 118 185   CMYK 100 36 0 27
  Edinext Green    #81B736   RGB 129 183 54   CMYK 30 0 70 28
  Ink              #0B1220   RGB 11 18 32   CMYK 66 44 0 87
  Night            #07101D   RGB 7 16 29   CMYK 76 45 0 89
  White            #FFFFFF   RGB 255 255 255   CMYK 0 0 0 0
  Mist             #F2F5F9   RGB 242 245 249   CMYK 3 2 0 2
  Line             #E3E8EF   RGB 227 232 239   CMYK 5 3 0 6
  Slate            #5A6679   RGB 90 102 121   CMYK 26 16 0 53
  CMYK values are reference conversions: confirm them with your printer's colour profile.

Press contact: info@edinext.it — +39 0832 242649
Edinext S.r.l. — Via Marco Biagi 26, 73100 Lecce (LE), Italy — www.edinext.it
